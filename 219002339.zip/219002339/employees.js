const collection ='employeeList'

const saveEmployee = (data,db,callback)=>{
    db.collection(collection).insertOne(data).then(result=>{
        callback(undefined,result)
    }).catch(error=>{
         callback(error,undefined)
    })
}

const getEmployeeDetails = (db,callback)=>{
    db.collection(collection)
    .find({})
    .toArray((error,result)=>
    {
        if(error) callback(error,undefined)
        callback(undefined,result)
    })
}

module.exports = {saveEmployee,getEmployeeDetails}