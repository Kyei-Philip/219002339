const express = require('express')
const mongodb = require('mongodb')
const {saveEmployee,getEmployeeDetails} = require('./employees')
const {saveTodoList,fetchTodoList} = require('./todoList')

const app = express()

const MongoClient = mongodb.MongoClient

const databaseName = 'EmployeeDB'
const connectionString ='mongodb://127.0.0.1:27017'
var db;

app.use(express.json())

app.listen(4200,()=>{
    MongoClient.connect(connectionString,{useNewUrlParser:true}).then(client=>{
        console.log('Database Connection Successful')
        db = client.db(databaseName)
    }).catch(err=>{
        console.log('Error in connecting to database ' + err)
    }) 
})

app.get('/employeeList',(req,res)=>{
    getEmployeeDetails(db,(error,result)=>{
        if(error) return res.send(error)
        res.send(result)
    })
})

app.get('/todoList',(req,res)=>{
    fetchTodoList(db,(err,response)=>{
        if(err) return res.send(err)
        res.send(response)
    })
})

app.post('/addEmployee',(req,res)=>{
    saveEmployee(req.body,db,(err,response)=>{
        if(err) return res.send(err)
        res.send(response)
    })
})

app.post('/addtodoList',(req,res)=>{
    saveTodoList(req.body,db,(err,response)=>{
        if(err) return res.send(err)
        res.send(response.ops)
    })
})






